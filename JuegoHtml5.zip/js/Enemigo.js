function Enemigo(x,y,imagen) {
    Kinetic.Image.call(this);//llamamos a la clase kinetic para usar sus metodos
    this.setWidth(60);
    this.setHeight(60);
    this.setX(x);
    this.setY(y);
    this.contador = 0;
    this.setImage(imagen);
    this.aleatorio = function(inferior,superior) {
        var posibilidades = superior - inferior;
        var ramdom = Math.random() * posibilidades;
        ramdom = Math.floor(ramdom);
        return parseInt(inferior) + ramdom;
    }
    this.mover = function() {
        this.contador++;
        // con el 50 y el 5 se definen que tanto se mueven los enemigos
        this.setX(this.getX() + Math.sin(this.contador * Math.PI / 50) * 5);
        
    }  
}

// a continuacion heredamos de la clase Kinetic.Rect y le damos esas
//porpiedades al objeto enemigo
Enemigo.prototype = Object.create(Kinetic.Image.prototype);