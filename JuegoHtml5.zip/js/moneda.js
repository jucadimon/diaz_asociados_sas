function Moneda(x,y,imagen) {
    Kinetic.Image.call(this);//llamamos a la clase kinetic para usar sus metodos
    this.setWidth(30);
    this.setHeight(30);
    this.setX(x);
    this.setY(y);
    this.setImage(imagen);
}
// a continuacion heredamos de la clase Kinetic.Rect y le damos esas
//porpiedades al objeto moneda
Moneda.prototype = Object.create(Kinetic.Image.prototype);