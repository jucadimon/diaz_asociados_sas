function Heroe(imagen) {
    Kinetic.Image.call(this);//llamamos a la clase kinetic para usar sus metodos
    this.setWidth(40);
    this.setHeight(60);
    this.vx = 15;//definimos la velocidad
    this.vy = 0;
    this.limiteDer = 0;
    this.limiteTope = 0;
    this.direccion = 1;
    this.contador = 0;
    this.setImage(imagen);
    
    this.caminar = function() {
        console.log('estoy caminando');
        this.move(this.vx,0);
        if (this.getX() > this.limiteDer) {
            this.move(this.limiteDer - this.getX(),0);
        }
    }
    this.retroceder = function() {
        console.log('estoy retrocediendo');
        this.move(-15,0);
        if (this.getX() < 0) {
            this.move(-this.getX(),0);
        }
    }
    this.saltar = function() {
        console.log('estoy saltando');
        this.vy = -20;
        this.contador++;
    }
    this.aplicarGravedad = function(gravedad,vRebote) {
        this.vy += gravedad;
        this.move(0,this.vy);
        if ( (this.getY() + this.getHeight()) > this.limiteTope) {
            this.setY(this.limiteTope - this.getHeight());
            this.vy = 0;
            this.contador = 0;
        }
    }    
}

// a continuacion heredamos de la clase Kinetic.Rect y le damos esas
//porpiedades al objeto heroe
Heroe.prototype = Object.create(Kinetic.Image.prototype);