var stage;//para el contendor del juego
var fondo;//para el fondo del personaje
var keyboard = {};//para leer desde el teclado
var intv;
var personaje;
var grupoAssets;//grupo de enemigos
var grav = 0.8;//el valor de la gravedad en el juego
var val_reb = 0;//cuando colisiona deberia rebotar se dan valores:
// numeros negativos para rebottar -1 hasta -0.001 y positivos si
//se desea que el objeto caiga con mas fuerza: 0.001 hasta 1.
var b = false;
var puntaje;
var juego = new Game();

var imgenemigo = new Image();
imgenemigo.src = 'imagenes/enemigo.png';
var imgHeroe = new Image();
imgHeroe.src = 'imagenes/Heroe.png';
var imgpersonaje = new Image();
imgpersonaje.src = 'imagenes/personaje.png';
var imgplataforma = new Image();
imgplataforma.src = 'imagenes/plataforma.png';
var imgpuerta = new Image();
imgpuerta.src = 'imagenes/puerta.png';
var imgmoneda = new Image();
imgmoneda.src = 'imagenes/moneda.png';

var imagenfondo;
var imgfondo = new Image();
imgfondo.src = 'imagenes/fondo.png';

var imgllave = new Image();
imgllave.src = 'imagenes/llave.png';



grupoAssets = new Kinetic.Group({
    x: 0,
    y: 0
})

stage = new Kinetic.Stage({
    container: 'juego',
    width: 860,
    height: 400
});

imagenfondo = new Kinetic.Image({
    x: 0,
    y: 0,
    image: imgfondo,
    width: stage.getWidth(),
    height: stage.getHeight()
});

puntaje = new Kinetic.Text({
    Text: 'Puntaje: 0',
    height: 25,
    width: 150,
    x: stage.getWidth() - 150,
    y: 15,
    fill: '#f7f7f7',
    fontFamily: 'Arial',
    fontSize: 20
})

//capa del juego
function nivelUno(){
    juego.puntaje = 0;
    if(b) return;
    b = true;
    
    juego.llave = true;
    juego.puntaje = 0;
    fondo = new Kinetic.Layer();
    /* Enemigos */
    grupoAssets.add(new Enemigo(20,(stage.getHeight()/1.9),imgenemigo));
    grupoAssets.add(new Enemigo(400,(stage.getHeight()/2.9),imgenemigo));
    grupoAssets.add(new Enemigo(600,(stage.getHeight()-75),imgenemigo));
    grupoAssets.add(new Enemigo(800,(stage.getHeight()-75),imgenemigo));
    
    /* plataformas */
    var piso = new Plataforma(0,(stage.getHeight() - 15),imgplataforma) ;
    piso.setWidth(stage.getWidth() * 2);
    grupoAssets.add(piso);
    grupoAssets.add(new Plataforma(20,(stage.getHeight()/1.5),imgplataforma));
    grupoAssets.add(new Plataforma(700,(stage.getHeight()/4.5),imgplataforma));
    grupoAssets.add(new Plataforma(400,(stage.getHeight()/2),imgplataforma));
    
    /* Monedas */
    grupoAssets.add(new Moneda(350,stage.getHeight()/3 - 130,imgmoneda));
    
    /* puerta */
    grupoAssets.add(new Puerta(900,stage.getHeight() - 85,imgpuerta));
    
    /* personaje */
    personaje = new Heroe(imgpersonaje);
    personaje.setX(0);
    personaje.setY(stage.getHeight() - personaje.getHeight());
    personaje.limiteDer = stage.getWidth() - personaje.getWidth();
    personaje.limiteTope = stage.getHeight();
    
    /* Añadir los participantes */
    fondo.add(imagenfondo);
    fondo.add(grupoAssets);
    fondo.add(personaje);
    fondo.add(puntaje);
    stage.add(fondo);
    
}

function nivelDos(){
    console.log('Bienvenido al nivel 2');
    //if(b) return;
    //b = true;
    
    fondo = new Kinetic.Layer();
    juego.llave = false;
    /* Enemigos */
    grupoAssets.add(new Enemigo(20,(stage.getHeight()/1.9),imgenemigo));
    grupoAssets.add(new Enemigo(400,(stage.getHeight()/2.9),imgenemigo));
    grupoAssets.add(new Enemigo(600,(stage.getHeight()-75),imgenemigo));
    grupoAssets.add(new Enemigo(800,(stage.getHeight()-75),imgenemigo));
    
    /* plataformas */
    var piso = new Plataforma(0,(stage.getHeight() - 15),imgplataforma) ;
    piso.setWidth(stage.getWidth() * 2);
    grupoAssets.add(piso);
    grupoAssets.add(new Plataforma(20,(stage.getHeight()/1.5),imgplataforma));
    grupoAssets.add(new Plataforma(700,(stage.getHeight()/4.5),imgplataforma));
    grupoAssets.add(new Plataforma(400,(stage.getHeight()/2),imgplataforma));
    
    /* Monedas */
    grupoAssets.add(new Moneda(350,stage.getHeight()/3 - 130,imgmoneda));
    
    /* puerta */
    grupoAssets.add(new Puerta(1600,stage.getHeight() - 85,imgpuerta));
    
    /* llave */
    grupoAssets.add(new Llave(1000,stage.getHeight() - 85,imgllave));
    
    /* personaje */
    personaje = new Heroe(imgpersonaje);
    personaje.setX(0);
    personaje.setY(stage.getHeight() - personaje.getHeight());
    personaje.limiteDer = stage.getWidth() - personaje.getWidth();
    personaje.limiteTope = stage.getHeight();
    
    /* Añadir los participantes */
    fondo.add(imagenfondo);
    fondo.add(grupoAssets);
    fondo.add(personaje);
    fondo.add(puntaje);
    stage.add(fondo);
    
    intv = setInterval(frameLoop,1000/20);//reinicio en el nivel 2
}

//funcion para mover el personaje
function moverPersonaje(){
    if (keyboard[37]) {
        personaje.retroceder();
    }
    if (keyboard[39]) {
        personaje.caminar();
    }
    if (keyboard[38] && personaje.contador < 1) {
        personaje.saltar();
    }
}

//añadimos esta funcion para los eventos por el teclado
function addKeyBoardEvents() {
    
    addEvent(document,"keydown",function (e) {
        keyboard[e.keyCode] = true;
    });
    
    addEvent(document,"keyup",function (e) {
        keyboard[e.keyCode] = false;
    });
    
    
    function addEvent(element,evenName,func) {
        if (element.addEventListener) {
            //para los navegadores distintos a internet explorer
            element.addEventListener(evenName,func,false);
        }
        else if(element.attachEvent){
            //pa el navegador internet explorer 
            element.attachEvent(evenName,func);
        }
    }
    
}


// Algoritmo para las colisiones de los objetos
function hit(a,b) {
    var hit = false;
    //colisiones horizontales
    if (b.getX() + b.getWidth() >= a.getX() && b.getX() < a.getX() + a.getWidth()) 
    {
        //colisiones verticales
        if (b.getY() + b.getHeight() >= a.getY() && b.getY() < a.getY() + a.getHeight())
        hit = true;
    }
    
    //colisiones de a con b
    if (b.getX() <= a.getX() && b.getX() + b.getWidth() >= a.getX() + a.getWidth()) 
    {
        if (b.getY() <= a.getY() && b.getY() + b.getHeight() >= a.getY() + a.getHeight())
        hit = true;
    }
    
    //colisiones de b con a
    if (a.getX() <= b.getX() && a.getX() + a.getWidth() >= b.getX() + b.getWidth()) 
    {
        if (a.getY() <= b.getY() && a.getY() + a.getHeight() >= b.getY() + b.getHeight())
        hit = true;
    }
    
    return hit;
}

//funcion para mover los enemigos
function moverEnemigos(){
    var enemigos = grupoAssets.children;
    for (i in enemigos){
        var enemigo = enemigos[i];
        if (enemigo instanceof Enemigo){
            enemigo.mover();
        }
    }
}

function detectarColisionPlataforma(){
    var plataformas = grupoAssets.children;
    for (i in plataformas){
        var plataforma = plataformas[i];
        if(hit(plataforma,personaje)){
            if(plataforma instanceof Enemigo){
                if(personaje.vy > 2 && personaje.getY() < plataforma.getY()){
                    plataforma.remove();
                    juego.puntaje += 5;
                    console.log(juego.puntaje);
                }
                else{
                    console.log('perdistes jaja');
                    grupoAssets.removeChildren();
                    document.querySelector('#perder').style.display = 'block';
                    document.querySelector('#juego').style.display = 'none';
                    document.querySelector('#score').innerHTML = juego.puntaje;
                    window.clearInterval(intv);
                    b = false;
                }
            }
            else if(plataforma instanceof Plataforma && personaje.getY() < plataforma.getY() && personaje.vy >=0){
                //comportamiento
                personaje.contador = 0;
                personaje.setY(plataforma.getY() - personaje.getHeight());
                personaje.vy *= val_reb;
            }
            else if(plataforma instanceof Moneda){
                plataforma.remove();
                juego.puntaje += 1;
                console.log(juego.puntaje);
            }
            else if(plataforma instanceof Llave){
                plataforma.remove();
                juego.llave = true;
                continue;//con este continue se salte del bucle y coje otra plataforma para continuar
            }
            else if(plataforma instanceof Puerta && juego.llave){
                if(juego.nivel == 1){
                    grupoAssets.removeChildren();
                    window.clearInterval(intv);
                    juego.nivel = 2;
                    nivelDos();
                }
                else if(juego.nivel == 2){
                    console.log('Ganaste!');
                    grupoAssets.removeChildren();
                    document.querySelector('#ganar').style.display = 'block';
                    document.querySelector('#juego').style.display = 'none';
                    document.querySelector('#score').innerHTML = juego.puntaje;
                    window.clearInterval(intv);
                    b = false;
                }
            }
        }
    }
}

function aplicarFuerzas(){
    personaje.aplicarGravedad(grav,val_reb);
}

function actualizarTexto(){
    puntaje.setText('Puntaje: '+juego.puntaje);
}

function moverFondo(){
    if(personaje.getX() > (stage.getWidth()/2) && keyboard[39]){
        personaje.vx = 2;
        for (i in grupoAssets.children){
            var asset = grupoAssets.children[i];
            asset.move(-5,0);
        }
    }
    else{
        personaje.vx = 10;
    }
}

function cargarBienvenida(){
    document.querySelector('#informacion').style.display = 'block';
}
function iniciarJuego(){
    document.querySelector('#informacion').style.display = 'none';
    document.querySelector('#ganar').style.display = 'none';
    document.querySelector('#perder').style.display = 'none';
    document.querySelector('#juego').style.display = 'block';
    nivelUno();
}
/*  loop del juego */
addKeyBoardEvents();
cargarBienvenida();


//document.querySelector(#informacion).style.display = 'block';
// mandar esta accion al preloader despues de cargar las imagenes
// mientras no se llegue a esa parte hay que dejarlo aquí: nivelUno();
//volver a poner si no anda el codigo ==>>>>> nivelUno();
//repite el loop 20 veces en un segundo, ademas se mueve al final del nivel1
//una vez que se carga el preloader: intv = setInterval(frameLoop,1000/20);
intv = setInterval(frameLoop,1000/20);


function frameLoop(){
    aplicarFuerzas();
    detectarColisionPlataforma();
    moverEnemigos();
    moverFondo();
    moverPersonaje();
    actualizarTexto();
    stage.draw();
}