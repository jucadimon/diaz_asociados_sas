function Plataforma(x,y,imagen) {
    Kinetic.Rect.call(this);//llamamos a la clase kinetic para usar sus metodos
    this.setWidth(200);
    this.setHeight(40);
    this.setX(x);
    this.setY(y); 
    this.setFillPatternImage(imagen); 
}
// a continuacion heredamos de la clase Kinetic.Rect y le damos esas
//porpiedades al objeto plataforma
Plataforma.prototype = Object.create(Kinetic.Rect.prototype);